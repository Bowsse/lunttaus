<?php

$db = new PDO('mysql:host=mysql.labranet.jamk.fi;dbname=K1803_1;charset=utf8',
              'K1803', '2B3bjnQJ3yWSKAbdzHQhgGLBxs1dYRTH');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

?>
<form action="T2.php" method="post">
    Suomi:  <input type="text" name="suomi" /><br />
    Ruotsi: <input type="text" name="ruotsi" /><br />
    <input type="submit" name="submit" value="Tallenna" />
</form>

<?php


$ruotsi   = isset($_REQUEST['ruotsi'])   ? $_REQUEST['ruotsi']   : '';
$suomi = isset($_REQUEST['suomi']) ? $_REQUEST['suomi'] : '';

if(isset($_REQUEST['ruotsi']) && isset($_REQUEST['suomi'])){
   $sql = "INSERT INTO sana (suomi, ruotsi) VALUES ('$suomi', '$ruotsi')";
    }

 ?>
    