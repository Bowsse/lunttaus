<?php
session_start();

if(!isset($_SESSION['n'])){
  $_SESSION['n']['Antti']       = 0;
  $_SESSION['n']['Martti']      = 0;
  $_SESSION['n']['Eero']        = 0;
  $_SESSION['n']['Eino']        = 0;
}


 if(isset($_GET['antti1']) ? $_GET['antti1'] : null){Inc('Antti');}
 if(isset($_GET['antti2']) ? $_GET['antti2'] : null){Dec('Antti');}
 if(isset($_GET['martti1']) ? $_GET['martti1'] : null){Inc('Martti');}
 if(isset($_GET['martti2']) ? $_GET['martti2'] : null){Dec('Martti');}
 if(isset($_GET['eero1']) ? $_GET['eero1'] : null){Inc('Eero');}
 if(isset($_GET['eero2']) ? $_GET['eero2'] : null){Dec('Eero');}
 if(isset($_GET['eino1']) ? $_GET['eino1'] : null){Inc('Eino');}
 if(isset($_GET['eino2']) ? $_GET['eino2'] : null){Dec('Eino');}

        function Inc($name)
          {
            $_SESSION['n'][$name] =$_SESSION['n'][$name]+1; 
          }

          function Dec($name)
          {
            $_SESSION['n'][$name] =$_SESSION['n'][$name]-1;  
          }

?>

<button type="button" class="nappi" id="antti1" name="antti1" onClick='location.href="?antti1=1"'>Antti</button>
<button type="button" class="nappi" id="antti2" name="antti2" onClick='location.href="?antti2=1"'>Antti</button>
<?php echo $_SESSION['n']['Antti'];?><br>
<button type="button" class="nappi" id="martti1" name="martti1" onClick='location.href="?martti1=1"'>Antti</button>
<button type="button" class="nappi" id="martti2" name="martti2" onClick='location.href="?martti2=1"'>Antti</button>
<?php echo $_SESSION['n']['Martti'];?><br>
<button type="button" class="nappi" id="eero1" name="eero1" onClick='location.href="?eero1=1"'>Antti</button>
<button type="button" class="nappi" id="eero2" name="eero2" onClick='location.href="?eero2=1"'>Antti</button>
<?php echo $_SESSION['n']['Eero'];?><br>
<button type="button" class="nappi" id="eino1" name="eino1" onClick='location.href="?eino1=1"'>Antti</button>
<button type="button" class="nappi" id="eino2" name="eino2" onClick='location.href="?eino2=1"'>Antti</button>
<?php echo $_SESSION['n']['Eino'];?>
